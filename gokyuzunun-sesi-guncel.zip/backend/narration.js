// Server-generated narration. The public API never accepts arbitrary speech text.
const Astronomy = require('astronomy-engine');

const SIGNS = ['Koç','Boğa','İkizler','Yengeç','Aslan','Başak','Terazi','Akrep','Yay','Oğlak','Kova','Balık'];
function finiteCoordinate(n, min, max) {
  return typeof n === 'number' && Number.isFinite(n) && n >= min && n <= max;
}
function placeLabel(label) {
  // Reject non-place punctuation so the caller cannot smuggle a custom speech script.
  const name = typeof label === 'string' ? label.trim() : '';
  return name.length > 0 && name.length <= 40 && /^[\p{L}\s,.'-]+$/u.test(name) ? name : 'Bulunduğun bölge';
}
function forecastCode(code) {
  if (code >= 95) return 'gök gürültülü yağışlı';
  if (code >= 71 && code <= 77 || code >= 85 && code <= 86) return 'karlı';
  if (code >= 51 && code <= 67 || code >= 80 && code <= 82) return 'yağmurlu';
  if (code >= 45 && code <= 48) return 'sisli';
  if (code >= 3) return 'bulutlu';
  if (code >= 1) return 'parçalı bulutlu';
  return 'açık';
}
function round(n) { return Math.round(Number(n)); }
function validSnapshot(s) {
  if(!s || typeof s !== 'object')return false;
  const inRange=(n,min,max)=>typeof n==='number'&&Number.isFinite(n)&&n>=min&&n<=max;
  return inRange(s.temp,-90,65)&&inRange(s.feels,-100,70)&&inRange(s.wind,0,300)&&
    inRange(s.code,0,99)&&inRange(s.min,-90,65)&&inRange(s.max,-90,65)&&
    inRange(s.rain,0,100)&&s.min<=s.max&&
    typeof s.sunrise==='string'&&/^\d{4}-\d\d-\d\dT([01]\d|2[0-3]):[0-5]\d/.test(s.sunrise)&&
    typeof s.sunset==='string'&&/^\d{4}-\d\d-\d\dT([01]\d|2[0-3]):[0-5]\d/.test(s.sunset);
}
function freshSnapshot(s,now){return validSnapshot(s)&&typeof s.observedAt==='number'&&Number.isFinite(s.observedAt)&&s.observedAt<=now.getTime()+60_000&&now.getTime()-s.observedAt<=15*60_000;}
function snapshotWeather(s){return {current:{temperature_2m:s.temp,apparent_temperature:s.feels,wind_speed_10m:s.wind,weather_code:s.code},daily:{time:[s.sunrise.slice(0,10)],temperature_2m_min:[s.min],temperature_2m_max:[s.max],precipitation_probability_max:[s.rain],sunrise:[s.sunrise],sunset:[s.sunset]}};}
function sunTime(s) { return typeof s === 'string' ? s.split('T')[1]?.slice(0,5) || 'bilinmiyor' : 'bilinmiyor'; }
function signAt(body, date) {
  const lon = body === Astronomy.Body.Moon
    ? Astronomy.EclipticGeoMoon(date).lon
    : Astronomy.Ecliptic(Astronomy.GeoVector(body,date,true)).elon;
  return SIGNS[Math.floor(((lon % 360) + 360) % 360 / 30)];
}
async function narration(profile, input, now = new Date(), fetchImpl = fetch) {
  const day = now.toISOString().slice(0,10);
  const duration=input.duration??'full', pace=input.pace??'normal';
  if(!['brief','full'].includes(duration)||!['normal','calm'].includes(pace))throw Object.assign(new Error('Invalid narration preferences'),{status:400});
  if (profile === 'astrology') {
    const sign = input.sign;
    if (!SIGNS.includes(sign)) throw Object.assign(new Error('Invalid zodiac sign'), {status:400});
    const moonSign = signAt(Astronomy.Body.Moon, now);
    const sunSign = signAt(Astronomy.Body.Sun, now);
    const mercurySign = signAt(Astronomy.Body.Mercury, now);
    const venusSign = signAt(Astronomy.Body.Venus, now);
    const marsSign = signAt(Astronomy.Body.Mars, now);
    const illumination = Math.round(Astronomy.Illumination(Astronomy.Body.Moon,now).phase_fraction*100);
    const phase = Astronomy.MoonPhase(now);
    const moonPhase = phase<22.5||phase>=337.5?'yeni Ay':phase<67.5?'büyüyen hilal':phase<112.5?'ilk dördün':phase<157.5?'büyüyen Ay':phase<202.5?'dolunay':phase<247.5?'küçülen Ay':phase<292.5?'son dördün':'küçülen hilal';
    return {
      cacheKey:'v3:astrology:'+day+':'+sign+':'+duration+':'+pace,
      pace,
      text:duration==='brief'?'Gökyüzünün Sesi. '+sign+' burcu için Ay '+moonSign+' bölümünde; evresi '+moonPhase+'. Bugün önceliklerini düşünmek için kendine zaman ayır. Bu sembolik bir yorumdur.':'Gökyüzünün Sesi ile hoş geldin. '+sign+' burcu için bugünün gökyüzüne birlikte bakalım. Güneş '+sunSign+', Ay '+moonSign+' bölümünde. Merkür '+mercurySign+', Venüs '+venusSign+' ve Mars '+marsSign+' bölümünde hesaplandı. Ayın evresi '+moonPhase+', aydınlanma oranı yüzde '+illumination+'. Bu gerçek astronomik konumları astrolojide bir düşünme daveti olarak ele alıyoruz. Bugün kendine nelerin önemli olduğunu, hangi konulara dikkat vermek istediğini sorabilirsin. Bu yorum semboliktir; gezegenler kişisel olayları bilimsel olarak öngörmez.',
    };
  }
  if(profile !== 'weather' || !finiteCoordinate(input.latitude,-90,90) || !finiteCoordinate(input.longitude,-180,180)) {
    throw Object.assign(new Error('Invalid location'),{status:400});
  }
  // Bucketing coordinates and UTC time limits redundant synthesis requests.
  const latitude = Math.round(input.latitude*20)/20;
  const longitude = Math.round(input.longitude*20)/20;
  const bucket = Math.floor(now.getUTCHours()/3);
  let cacheKey = 'v3:weather:'+day+':'+bucket+':'+latitude+':'+longitude;
  const params = new URLSearchParams({
    latitude:String(latitude),longitude:String(longitude),
    current:'temperature_2m,apparent_temperature,wind_speed_10m,weather_code',
    daily:'temperature_2m_min,temperature_2m_max,precipitation_probability_max,sunrise,sunset',
    forecast_days:'1',timezone:'auto',
  });
  let w;
  if(freshSnapshot(input.weatherSnapshot,now)){
    w=snapshotWeather(input.weatherSnapshot);
    cacheKey+=':device:'+round(input.weatherSnapshot.temp)+':'+round(input.weatherSnapshot.rain)+':'+round(input.weatherSnapshot.code);
  }
  else try {
    const response=await fetchImpl('https://api.open-meteo.com/v1/forecast?'+params,{signal:AbortSignal.timeout(12000)});
    if(!response.ok) {
      console.error(JSON.stringify({event:'weather_upstream_rejected',providerStatus:response.status}));
      if(response.status!==429)throw Object.assign(new Error('Weather service unavailable'),{status:503});
    } else w=await response.json();
  } catch(error){
    if(!validSnapshot(input.weatherSnapshot))throw error;
  }
  if(!w && validSnapshot(input.weatherSnapshot)){
    w=snapshotWeather(input.weatherSnapshot);
    cacheKey+=':device:'+round(input.weatherSnapshot.temp)+':'+round(input.weatherSnapshot.rain)+':'+round(input.weatherSnapshot.code);
  }
  if(!w?.current || !w.daily?.time?.length) throw Object.assign(new Error('Forecast unavailable'),{status:503});
  const name=placeLabel(input.place);
  const rain=round(w.daily.precipitation_probability_max[0]);
  const min=round(w.daily.temperature_2m_min[0]);
  const max=round(w.daily.temperature_2m_max[0]);
  const temp=round(w.current.temperature_2m);
  const feels=round(w.current.apparent_temperature);
  const wind=round(w.current.wind_speed_10m);
  const advice=rain>=50?'Şemsiyeni yanına almayı unutma.':wind>=45?'Rüzgâr güçlü olabilir, dışarıda dikkatli ol.':min<=5?'Sabah serinliği için kalın giyin.':max>=32?'Sıcak havada bol su iç.':'Günün tadını çıkar.';
  return {
    cacheKey:cacheKey+':'+duration+':'+pace,
    pace,
    text:duration==='brief'?'Merhaba. '+name+' için hava '+forecastCode(w.current.weather_code)+', sıcaklık '+temp+' derece. Yağış olasılığı yüzde '+rain+'. '+advice:'Merhaba, Gökyüzünün Sesi seninle. '+name+' için hava durumuna birlikte bakalım. Şu anda hava '+forecastCode(w.current.weather_code)+'. Sıcaklık '+temp+' derece, hissedilen '+feels+' derece. Bugün en düşük '+min+', en yüksek '+max+' derece bekleniyor. Yağış olasılığı yüzde '+rain+'. Rüzgâr saatte '+wind+' kilometre. Güneş '+sunTime(w.daily.sunrise[0])+' saatinde doğuyor, '+sunTime(w.daily.sunset[0])+' saatinde batıyor. '+advice,
  };
}
module.exports={narration,placeLabel,forecastCode,SIGNS};
